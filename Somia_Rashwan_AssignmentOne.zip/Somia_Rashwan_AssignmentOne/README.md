# <a href="https://github.com/rhildred/es6-twilio-chatbot" target="_blank">es6-twilio-chatbot</a>

I got the user interface for the web from a student of mine, Pat Wilken.

A chatbot written in es6 and vs6 for twilio and testing on the web. The important files are index.js and game.js.

A popular theme for the upcoming Halloween holiday is to make haunted house simulations. You will make a choose your own adventure for a haunted house presented as a Twilio chatbot. 

Marking
-----

|Element|Out Of|
|---|---|
|get a game or choose your own adventure in es6| 50|
|multiplayer - each person plays their own game against the bot.| 10|
|count case and if statements|2/3 each up to 20 points|
|spelling and grammar|10|
|on time|10|




